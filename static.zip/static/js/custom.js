
$(document).ready(function(){
    $(".journal").click(function(){
        alert("This feature is under process !");
    });

    $(".quiz").click(function(){
        alert("This feature is under process !");
    });

    // $("#member").click(function(){
    //     alert("You are not a verified DOA member, please contact your administration!");
    // });
});
