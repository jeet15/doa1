from django.contrib import admin

# Register your models here.
from .models import Officebearers, Pastofficebearers, Pastmembers, Doanews, Doaevents, Archivejournal, Awards

admin.site.register(Officebearers)
admin.site.register(Pastofficebearers)
admin.site.register(Pastmembers)
admin.site.register(Doanews)
admin.site.register(Doaevents)
admin.site.register(Archivejournal)
admin.site.register(Awards)