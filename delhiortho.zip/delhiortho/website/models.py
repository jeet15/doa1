from django.db import models

# Create your models here.


class Officebearers(models. Model):
	"""docstring for Officebearers"""

	name = models.CharField(max_length=200)
	email = models.CharField(max_length=250)
	phone = models.IntegerField(null=True)
	designation = models.CharField(max_length=250)
	image = models.FileField(upload_to = 'media')

	def __str__(self):
		return self.name + ' | ' + self.name


class Pastofficebearers(models. Model):
	"""docstring for Officebearers"""

	name = models.CharField(max_length=200)
	email = models.CharField(max_length=250)
	phone = models.IntegerField(null=True)
	designation = models.CharField(max_length=250)
	image = models.FileField(upload_to = 'pastmembers')

	def __str__(self):
		return self.name + ' | ' + self.name


class Pastmembers(models. Model):
	"""docstring for Officebearers"""

	year = models.IntegerField(null=True)
	president = models.CharField(max_length=200, null=True,  blank=True)
	secretary = models.CharField(max_length=200, null=True,  blank=True)
	treasurer = models.CharField(max_length=200, null=True,  blank=True)
	editor = models.CharField(max_length=200, null=True,  blank=True)
	annualmeet = models.CharField(max_length=200, null=True,  blank=True )

	def __str__(self):
		return self.president + ' | ' + self.president

class Doanews(models. Model):
	"""docstring for Officebearers"""

	title = models.CharField(max_length=200)
	year = models.IntegerField(null=True)
	description = models.TextField()
	newsfile = models.FileField(upload_to = 'doanews')

	def __str__(self):
		return self.title + ' | ' + self.title


class Doaevents(models. Model):
	"""docstring for Officebearers"""
	YEAR_CHOICES = (
    ('January','January'),
    ('Feburary', 'Feburary'),
    ('March','March'),
    ('April','April'),
    ('May','May'),
    ('June','June'),
    ('July','July'),
    ('August','August'),
    ('September','September'),
    ('October','October'),
    ('November','November'),
    ('December','December'),
)

	title = models.CharField(max_length=200)
	category = models.CharField(max_length=150, default='upcoming')
	edate = models.IntegerField(null=True)
	emonth = models.CharField(max_length=20, choices=YEAR_CHOICES, null=True,)
	eyear = models.IntegerField(null=True)
	description = models.TextField()
	efile = models.FileField(null=True, blank=True ,upload_to = 'eventfile')

	def __str__(self):
		return self.title + ' | ' + self.title


class Archivejournal(models. Model):
	"""docstring for Officebearers"""

	title = models.CharField(max_length=200)
	year = models.IntegerField(null=True)
	description = models.TextField()
	archivefile = models.FileField(upload_to = 'archivejournal')

	def __str__(self):
		return self.title + ' | ' + self.year





class Awards(models. Model):
	"""docstring for Officebearers"""

	title = models.CharField(max_length=200)
	person = models.CharField(max_length=250)
	year = models.IntegerField(null=True)
	awardfile = models.FileField(upload_to = 'awards', null=True,  blank=True)

	def __str__(self):
		return self.title + ' | ' + self.person


class members(models.Model):
	MEMBER_TYPE = (
    ('lifetime','Lifetime Member'),
    ('associate', 'Associate Member'),
)
	membertype = models.CharField(choices=MEMBER_TYPE, max_length=200)
	memberfees = models.IntegerField(null=True)
	firstname = models.CharField(max_length=255)
	lastname = models.CharField(max_length=255)
	postaddress = models.CharField(max_length=555)
	peraddress = models.CharField(max_length=555)
	state = models.CharField(max_length=355)
	pincode = models.IntegerField(null=True)
	study = models.CharField(max_length=555)
	institute = models.CharField(max_length=355)
	interest = models.CharField(max_length=555)
	extrainterest = models.CharField(max_length=355)
	hospital = models.CharField(max_length=555)
	position = models.CharField(max_length=255)
	clinicaddress = models.CharField(max_length=555)
	contactno = models.IntegerField(null=True)
	mobile = models.IntegerField(null=True)
	paymenttype = models.CharField(max_length=200)
	paymentscreen = models.FileField(upload_to = 'members')
	degreescreen = models.FileField(upload_to = 'members')
	certificatecreen = models.FileField(upload_to = 'members')

	def __str__(self):
		return self.membertype + ' | ' + self.firstname