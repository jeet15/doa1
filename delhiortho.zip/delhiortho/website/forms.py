import os
from django import forms
from .models import members
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.template import loader


class MemberRegistrationForm(forms.Form):
	MEMBER_TYPE = (
    ('lifetime','Lifetime Member'),
    ('associate', 'Associate Member'),
)
	membertype = forms.CharField(label='Member Type', widget = forms.Select(attrs={'class':'col-20'}),choices=MEMBER_TYPE, initial='')
	memberfees = forms.CharField(label='Fees Amount',widget=forms.TextInput(attrs={'class':'col-20' ,'placeholder':'Pincode'}))
	memberfees = models.IntegerField(null=True)
	firstname = models.CharField(max_length=255)
	lastname = models.CharField(max_length=255)
	postaddress = models.CharField(max_length=555)
	peraddress = models.CharField(max_length=555)
	state = models.CharField(max_length=355)
	pincode = models.IntegerField(null=True)
	study = models.CharField(max_length=555)
	institute = models.CharField(max_length=355)
	interest = models.CharField(max_length=555)
	extrainterest = models.CharField(max_length=355)
	hospital = models.CharField(max_length=555)
	position = models.CharField(max_length=255)
	clinicaddress = models.CharField(max_length=555)
	contactno = models.IntegerField(null=True)
	mobile = models.IntegerField(null=True)
	paymenttype = models.CharField(max_length=200)
	paymentscreen = models.FileField(upload_to = 'members')
	degreescreen = models.FileField(upload_to = 'members')
	certificatecreen = models.FileField(upload_to = 'members')