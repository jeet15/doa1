import os
from django import forms
from .models import members, Newmember
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login, logout
from django.template import loader


# class MemberRegistrationForm(forms.ModelForm):
# 	class Meta:
# 		model = members
# 		fields = ('membertype', 'memberfees', 'firstname', 'lastname', 'postaddress', 'peraddress', 'state', 'pincode', 'study', 'institute', 'interest', 'paymentscreen', 'extrainterest','hospital', 'position', 'clinicaddress','contactno', 'mobile', 'paymenttype', 'paymentscreen', 'degreescreen', 'certificatecreen')
# 		MEMBER_TYPE = (    ('lifetime','Lifetime Member'),    ('associate', 'Associate Member'))
# 		PAYMENT_CHOICES=[('NEFT','NEFT'),
#          ('Cheque ','select 2'), ('Cash Deposit','Cash Deposit')]
# 		widget = {
# 			'membertype' :forms.Select(attrs={'class':'form-control col-md-6'}, choices = MEMBER_TYPE),
# 			'memberfees':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Amount', 'readonly':'true'}),
# 			'firstname':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'First Name'}),
# 			'lastname':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Last Name'}),
# 			'postaddress':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Postal Address'}),
# 			'peraddress':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Permanent Address'}),
# 			'state':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'State'}),
# 			'pincode':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Pincode'}),
# 			'study':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Education'}),
# 			'institute':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Institute Name'}),
# 			'interest':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Interested Area'}),
# 			'extrainterest':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Extra Activities'}),
# 			'hospital':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Working Hospital'}),
# 			'position':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Position'}),
# 			'clinicaddress':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Clinic Address'}),
# 			'contactno':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Contact No.'}),
# 			'mobile':forms.TextInput(attrs={'class':'form-control col-md-6' , 'placeholder':'Mobile Number'}),
# 			'paymenttype':forms.ChoiceField(attrs={'class':'form-control col-md-6'}, choices = PAYMENT_CHOICES),
# 			'paymentscreen':forms.FileField(), 		
# 			'degreescreen':forms.FileField(), 		
# 			'certificatecreen':forms.FileField(), 		
# 			}

# 	def get_absolute_url(self):
# 		print(self.id)
# 		return reverse('home')