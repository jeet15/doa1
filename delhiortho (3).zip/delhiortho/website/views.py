from django.template.defaultfilters import date
import datetime
from django.shortcuts import render
from django.views.generic import ListView, DetailView, CreateView
from .models import Officebearers, Pastofficebearers, Pastmembers, Doanews, Doaevents, Archivejournal, Awards, members, Newmember,Eposter,Homeslider
# from .forms import MemberRegistrationForm

# Create your views here.
#def home(request):
#	return render(request, 'home.html', {})

class HomeView(ListView):
    template_name = 'home.html'
    queryset = Officebearers.objects.all()
    this_month = datetime.datetime.now()
    new_month = this_month.strftime("%B")
    this_year = this_month.year
    queryset1 = Doaevents.objects.filter(emonth=new_month)
    queryset2 = Doanews.objects.filter(year = this_year)

    def get_context_data(self, **kwargs):
    	
        context = super(HomeView, self).get_context_data(**kwargs)
        context['event'] = self.queryset1
        context['post'] = self.queryset
        context['news'] = self.queryset2
        return context

# class AddMemberView(CreateView):
# 	model = Newmember
# 	form_class = MemberRegistrationForm
# 	template_name = 'add-member.html'
	
# class EventDetailView(DetailView):
	
# 	model = Doaevents
# 	template_name = "event_details.html"

# 	def get_context_data(self, **kwargs):
# 		context = super(EventDetailView, self).get_context_data(**kwargs)
# 		print(context)
# 		return context


class EventView(ListView):
	model = Doaevents
	template_name = 'doa-events.html'
	# def get_context_data(self, **kwargs):
    	
 #        context = super(EventView, self).get_context_data(**kwargs)
 #        context['event'] = self.queryset1
 #        return context



class EventDetailView(DetailView):
	# model = Doaevents
	queryset = Doaevents.objects.all()
	template_name = 'detail_list.html'
	def get_context_data(self, *args,**kwargs):
		print(self.kwargs)
		context = super(EventDetailView, self).get_context_data(*args, **kwargs)
		print(context)
		return context


def president_message(request):
	return render(request, 'president-message.html', {})


def secretary_message(request):
	return render(request, 'secretary-message.html', {})


class PastOfficebearersView(ListView):
	model = Pastofficebearers
	template_name = 'office-bearers-2018-19.html'


class OfficebearersView(ListView):
	model = Officebearers
	template_name = 'office-bearers-2019-20.html'


def doaelections2019_2020(request):
	return render(request, 'doa-elections-2019-2020.html', {})


class PastpresidentView(ListView):
	model = Pastmembers
	template_name = 'past-presidents-and-secretaries.html'


class DoanewsView(ListView):
	model = Doanews
	template_name = 'doa-news.html'



class DoaAllEventView(ListView):
	model = Doaevents
	template_name = 'doa-events.html'




def archived_events(request):
	return render(request, 'archived-events.html', {})


def doa_fellowship(request):
	return render(request, 'doa-fellowship.html', {})


class DoaawardsView(ListView):
	model = Awards
	template_name = 'doacon-award-2019.html'


def doa_journal(request):
	return render(request, 'doa-journal.html', {})


def archive():
	return render(request, 'archive.html', {})



def doa_journal_archive(request):
	return render(request, 'doa-journal-archive.html', {})

def member_registration(request):
	return render(request, 'member-registration.html', {})


def subspeciality(request):
	return render(request, 'subspeciality.html', {})


def photo_gallery(request):
	return render(request, 'photo-gallery.html', {})

def member_login(request):
	return render(request, 'member-login.html', {})

def covid(request):
	return render(request, 'covid_19.html', {})


class EposterView(ListView):
	model = Eposter
	template_name = 'eposter.html'





def contact(request):
	return render(request, 'contact.html', {})
